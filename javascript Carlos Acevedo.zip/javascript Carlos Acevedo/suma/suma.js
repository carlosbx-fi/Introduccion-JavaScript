/* suma.js */
numero1 = 100
numero2 = 50
alert(numero1 + numero2)
